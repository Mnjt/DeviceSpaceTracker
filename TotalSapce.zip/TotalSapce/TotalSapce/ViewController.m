//
//  ViewController.m
//  TotalSapce
//
//  Created by Shine Dezign on 13/04/16.
//  Copyright © 2016 shine.dezign. All rights reserved.
//

#import "ViewController.h"
#import "ALDisk.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSLog(@"1 Free DiskSpace %@",[ALDisk usedDiskSpace]);
    NSLog(@"2 Used DiskSpaceInBytes %f",[ALDisk usedDiskSpaceInBytes]);
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
