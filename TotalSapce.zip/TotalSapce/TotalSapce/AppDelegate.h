//
//  AppDelegate.h
//  TotalSapce
//
//  Created by Shine Dezign on 13/04/16.
//  Copyright © 2016 shine.dezign. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

